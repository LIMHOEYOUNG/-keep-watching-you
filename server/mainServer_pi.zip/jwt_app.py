import datetime
from django.http import JsonResponse
from rest_framework import status
import jwt

SECRET_PRE = "Leedong"

def create_token(token, email):

    encoded = jwt.encode(
        payload = {'exp': datetime.datetime.utcnow() + datetime.timedelta(days = 100),
                   'email': email},
        key = SECRET_PRE + token,
        algorithm = 'HS256')
    return encoded

def validate_token(get_token, token):
    try:
        x=jwt.decode(get_token, SECRET_PRE + token, algorithms = 'HS256')
    except jwt.ExpiredSignatureError:
        return JsonResponse({"message": "EXPIRED_TOKEN"}, status = 400)
        #return status.HTTP_401_UNAUTHORIZED
    except jwt.InvalidTokenError:
        return status.HTTP_401_UNAUTOHRIZED
    else:
        return x

#qq=create_token('tlqkf','ldh')
#print(qq)
#print(jwt.decode(qq,SECRET_PRE +'tlqkf',algorithms = 'HS256'))

