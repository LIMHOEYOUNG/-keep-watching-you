from rest_framework import serializers
from restapp.models import DriveUserTb

class MyModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = DriveUserTb
        #fields = ("__all__")
        fields = ['id', 'passwd', 'name', 'email','client_token','app_token','sleep_model','face_model']