from django.shortcuts import render
from rest_framework import viewsets
from restapp.models import DriveUserTb
from restapp.serializers import MyModelSerializer
# Create your views here.
class MyModelViewSet(viewsets.ModelViewSet):
    queryset = DriveUserTb.objects.all()
    serializer_class = MyModelSerializer