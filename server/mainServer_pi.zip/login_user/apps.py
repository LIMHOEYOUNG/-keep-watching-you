from django.apps import AppConfig


class LoginUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'login_user'
